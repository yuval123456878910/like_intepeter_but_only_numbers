cd setup
setup.bat